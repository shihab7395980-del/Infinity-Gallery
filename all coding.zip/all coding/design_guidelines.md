# Design Guidelines: Infinity Gallery E-Commerce Application

## Design Approach
**Reference-Based**: Drawing inspiration from successful fashion e-commerce platforms like ASOS, Zara online stores, and regional platforms like Daraz. The design emphasizes product showcase, trust-building, and seamless mobile shopping experience for the Bangladesh market.

## Core Design Principles
1. **Mobile-First**: Optimize primarily for smartphone users (primary shopping device in Bangladesh)
2. **Trust & Credibility**: Prominent display of trust badges, contact information, and policy transparency
3. **Visual Product Focus**: Large, high-quality product imagery with clean, minimal interference
4. **Conversion-Optimized**: Clear CTAs, simplified checkout flow, WhatsApp integration

---

## Typography System

**Font Families** (via Google Fonts):
- **Primary**: Inter (400, 500, 600, 700) - UI elements, body text, navigation
- **Accent**: Outfit (600, 700) - Headings, hero text, trust badges

**Type Scale**:
- Hero/H1: text-5xl lg:text-6xl font-bold
- H2 (Section Titles): text-3xl lg:text-4xl font-semibold
- H3 (Product Names): text-xl lg:text-2xl font-semibold
- Body Text: text-base font-normal
- Small Text (Prices, Labels): text-sm font-medium
- Micro Text (Footer): text-xs

---

## Layout System

**Spacing Primitives**: Use Tailwind units of 4, 6, 8, 12, 16
- Component padding: p-4, p-6, p-8
- Section spacing: py-12, py-16
- Gap spacing: gap-4, gap-6, gap-8

**Container Structure**:
- Max width: max-w-7xl mx-auto
- Product grids: max-w-6xl
- Content sections: px-4 lg:px-8

**Grid System**:
- Product Grid: grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4
- Feature Grid: grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6
- Footer: grid-cols-1 md:grid-cols-3 gap-8

---

## Component Library

### Navigation
**Sticky Header**: sticky top-0 z-50
- Logo (left): h-8 lg:h-10
- Desktop Nav: Categories, About, Contact, Policies (hidden on mobile)
- Icons: Shopping cart with badge, Search icon
- Mobile: Hamburger menu, full-screen overlay navigation
- WhatsApp floating button: fixed bottom-6 right-6 z-40

### Hero Section
**Full-width banner**: h-[500px] lg:h-[600px]
- Background: Product lifestyle image with overlay
- Content: Centered, max-w-2xl
- Headline + Trust badges (5 items in grid-cols-2 lg:grid-cols-5)
- CTA Button: Large, prominent with blurred background backdrop-blur-sm

### Product Cards
**Card Structure**: Aspect ratio 3:4 for product images
- Image container with hover zoom effect
- Product name (truncate-2-lines)
- Price: Large, bold
- Quick view icon overlay (appears on hover, desktop only)
- Add to cart button: Full width at bottom

### Trust Badges Section
**Grid Layout**: grid-cols-2 lg:grid-cols-5
- Icon (Heroicons): size-8
- Text: Short, punchy (e.g., "100% Genuine")
- Spacing: Generous padding p-6

### Product Detail Page
**Two-column layout** (md:grid-cols-2):
- Left: Image gallery (main image + thumbnails below)
- Right: Product info, size/color selectors (radio buttons), quantity, Add to Cart + WhatsApp Order buttons (stacked vertically)

### Checkout Flow
**Single page form** (max-w-3xl):
- Cart summary (collapsible on mobile)
- Customer details form (name, phone, address, district/city)
- Payment method selection (large radio cards for COD/bKash)
- Order summary sidebar (sticky on desktop)

### Footer
**Three-column grid** (md:grid-cols-3):
- Column 1: About snippet, logo
- Column 2: Quick links (Policies, About, Contact)
- Column 3: Contact info (phone, WhatsApp, social)
- Bottom bar: Copyright text, payment method icons

### Policy Pages
**Simple layout**: max-w-3xl mx-auto
- Clear headings (h2, h3)
- Bullet points with generous line-height (leading-relaxed)
- Highlighted boxes for important notices (border-l-4 pl-4)

---

## Interaction Patterns

**Micro-interactions** (subtle):
- Product card hover: slight scale (scale-105)
- Button hover: brightness adjustment
- Cart icon: shake animation on item add
- Image zoom: overflow-hidden with scale on hover

**Loading States**:
- Skeleton loaders for product grids
- Spinner for cart operations

**Mobile Drawer**:
- Slide-in navigation from left
- Slide-in cart from right
- Full-screen product quick view

---

## Images

### Hero Section
**Large lifestyle image** showing fashion products in use (600px height desktop, 500px mobile)
- Overlaid with semi-transparent gradient for text readability
- Position: Center, covers full width

### Product Images
**High-quality product photography** (3:4 aspect ratio recommended)
- White or minimal background for catalog
- Lifestyle shots for detail pages
- Minimum 800x1066px resolution

### Trust Section
**Icon-based** (using Heroicons):
- Shield for "Genuine Products"
- Truck for "Fast Delivery"  
- Cash for "COD Available"
- Phone for "WhatsApp Support"
- Credit Card for "bKash Payment"

### About/Contact Pages
**Optional banner images** at top (h-64) showing team or store

---

## Responsive Behavior

**Breakpoints**:
- Mobile: base (< 768px) - Single column, stacked navigation
- Tablet: md (768px+) - 2-3 column grids, horizontal navigation
- Desktop: lg (1024px+) - 4 column grids, full navigation, sticky sidebar

**Mobile Optimizations**:
- Larger tap targets (min-h-12)
- Full-width CTAs
- Simplified navigation
- WhatsApp quick action always visible