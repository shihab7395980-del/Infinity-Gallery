# Infinity Gallery E-Commerce Platform

## Overview

Infinity Gallery is a Bangladesh-based e-commerce platform specializing in fashion and accessories. The application is built as a full-stack TypeScript solution with a React frontend and Express backend, featuring a product catalog, shopping cart functionality, and order management system. The platform emphasizes mobile-first design, trust-building elements (COD, WhatsApp support), and a streamlined checkout experience tailored for the Bangladeshi market.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System:**
- React with TypeScript for type safety
- Vite as the build tool and development server
- Wouter for lightweight client-side routing
- TanStack Query for server state management and API caching

**UI Framework:**
- Shadcn UI component library (New York style variant)
- Tailwind CSS for styling with custom design tokens
- Radix UI primitives for accessible, unstyled components
- Custom design system with defined typography (Inter, Outfit fonts) and spacing primitives

**State Management Strategy:**
- React Query for server state (products, orders)
- Local React state for cart management with localStorage persistence
- Form state managed by React Hook Form with Zod validation

**Key Design Decisions:**
- Mobile-first responsive design optimized for smartphone users
- Trust-building UI elements prominently displayed (COD badge, WhatsApp support, genuine product guarantee)
- Component-based architecture with reusable UI elements
- Persistent shopping cart using localStorage for session continuity

### Backend Architecture

**Runtime & Framework:**
- Node.js runtime with Express.js web framework
- TypeScript for type safety across the stack
- ESM module system for modern JavaScript features

**API Design:**
- RESTful API endpoints (`/api/products`, `/api/orders`)
- JSON request/response format
- Zod schema validation for incoming data
- Separation of development and production server configurations

**Data Layer:**
- In-memory storage implementation (MemStorage) with interface-based design (IStorage)
- Drizzle ORM configured for PostgreSQL (schema defined, ready for database integration)
- Seed data for sample products included in memory storage
- Schema-first approach with shared types between frontend and backend

**Storage Architecture Decision:**
The application currently uses in-memory storage but is architected with an IStorage interface to enable easy migration to PostgreSQL. The Drizzle schema is fully defined in `shared/schema.ts`, allowing seamless transition from MemStorage to database-backed storage without changing business logic.

### Data Models

**Product Schema:**
- Unique ID, name, description, price (decimal)
- Category classification (fashion, accessories, lifestyle)
- Image URL, available sizes and colors (arrays)
- Stock status and featured flag (booleans)

**Order Schema:**
- Customer information (name, phone, address, city)
- Payment method (COD or bKash)
- Cart items with product details and quantities
- Total amount calculation
- Optional bKash transaction ID for digital payments

**Cart Item Schema:**
- Product reference, quantity, selected size/color
- Cached product details (name, price, image) for quick display

### External Dependencies

**Database:**
- Drizzle ORM (v0.39.1) for type-safe database queries
- Drizzle Kit for schema migrations
- Neon Database serverless driver (@neondatabase/serverless v0.10.4)
- PostgreSQL as the target database (configured but not yet connected)

**Third-Party Services:**
- WhatsApp Business integration for customer support (phone: 01612963954)
- bKash payment gateway (manual transaction ID entry, not automated)
- Image hosting via Unsplash for product photos

**Development Tools:**
- Replit-specific plugins (cartographer, dev-banner, runtime-error-modal)
- TSX for TypeScript execution in development
- ESBuild for production bundling

**UI Component Libraries:**
- 25+ Radix UI primitives for accessible components
- Embla Carousel for product image galleries
- Lucide React for consistent iconography
- class-variance-authority and clsx for conditional styling

### Build & Deployment Strategy

**Development Mode:**
- Vite dev server with HMR
- Express backend proxy
- Separate client/server processes via tsx

**Production Build:**
- Vite builds static assets to `dist/public`
- ESBuild bundles server code to `dist/index.js`
- Single production server serves both API and static files
- Static file serving with SPA fallback to index.html

**Configuration Management:**
- Environment-based configuration (NODE_ENV)
- Database URL via environment variable
- Path aliases for clean imports (@/, @shared/, @assets/)