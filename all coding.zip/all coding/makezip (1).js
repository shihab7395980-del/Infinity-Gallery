const { zip } = require("zip-a-folder");

async function main() {
  await zip(".", "./app.zip");
  console.log("ZIP তৈরি হয়েছে: app.zip");
}

main();