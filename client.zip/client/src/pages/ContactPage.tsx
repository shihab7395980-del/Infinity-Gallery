import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Phone, MessageCircle, Mail, MapPin } from "lucide-react";

export function ContactPage() {
  return (
    <div className="min-h-screen py-12">
      <div className="max-w-4xl mx-auto px-4 lg:px-8">
        <h1 className="text-3xl lg:text-4xl font-heading font-bold mb-6" data-testid="text-contact-title">
          Contact Us
        </h1>

        <p className="text-lg text-muted-foreground mb-12">
          Have questions? We're here to help! Contact us through any of the channels below.
        </p>

        <div className="grid md:grid-cols-2 gap-6 mb-12">
          <Card className="hover-elevate transition-all">
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 shrink-0">
                  <Phone className="h-6 w-6 text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-lg mb-2">Phone</h3>
                  <p className="text-muted-foreground mb-3">Call us anytime</p>
                  <a
                    href="tel:01612963954"
                    className="text-primary hover:underline font-medium"
                    data-testid="link-phone"
                  >
                    01612963954
                  </a>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover-elevate transition-all">
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 shrink-0">
                  <MessageCircle className="h-6 w-6 text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-lg mb-2">WhatsApp</h3>
                  <p className="text-muted-foreground mb-3">24/7 Support Available</p>
                  <Button
                    variant="outline"
                    onClick={() => window.open("https://wa.me/8801612963954", "_blank")}
                    data-testid="button-whatsapp-contact"
                  >
                    Chat on WhatsApp
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover-elevate transition-all">
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 shrink-0">
                  <Mail className="h-6 w-6 text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-lg mb-2">Email</h3>
                  <p className="text-muted-foreground mb-3">Send us a message</p>
                  <a
                    href="mailto:infinitygallery.support@gmail.com"
                    className="text-primary hover:underline font-medium break-all"
                    data-testid="link-email"
                  >
                    infinitygallery.support@gmail.com
                  </a>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover-elevate transition-all">
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 shrink-0">
                  <MapPin className="h-6 w-6 text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-lg mb-2">Location</h3>
                  <p className="text-muted-foreground mb-3">We ship across Bangladesh</p>
                  <p className="font-medium">Bangladesh</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="bg-primary text-primary-foreground">
          <CardContent className="p-8 text-center">
            <h2 className="text-2xl font-heading font-bold mb-4">Customer Care Hours</h2>
            <p className="text-lg mb-2">We are available 24/7 for your support</p>
            <p className="text-sm opacity-90">Fastest response via WhatsApp</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
