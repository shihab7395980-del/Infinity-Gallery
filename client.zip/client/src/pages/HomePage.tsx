import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Shield, Truck, Banknote, MessageCircle, CreditCard } from "lucide-react";

export function HomePage() {
  const trustBadges = [
    { icon: Shield, text: "100% Genuine Products", testId: "badge-genuine" },
    { icon: Truck, text: "Fast Delivery", testId: "badge-delivery" },
    { icon: Banknote, text: "COD Available", testId: "badge-cod" },
    { icon: MessageCircle, text: "WhatsApp Support", testId: "badge-whatsapp" },
    { icon: CreditCard, text: "bKash Payment", testId: "badge-bkash" },
  ];

  return (
    <div className="min-h-screen">
      <section className="relative h-[500px] lg:h-[600px] flex items-center justify-center overflow-hidden bg-gradient-to-br from-primary/20 via-accent/10 to-background">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/10 via-transparent to-transparent"></div>
        
        <div className="relative z-10 max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-heading font-bold mb-6 leading-tight" data-testid="text-hero-title">
            Welcome to Infinity Gallery
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Your trusted online shopping store. High-quality products at the best prices, 
            fast delivery all over Bangladesh, and secure payment options.
          </p>
          
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8 max-w-3xl mx-auto">
            {trustBadges.map((badge, index) => (
              <Card key={index} className="hover-elevate transition-all" data-testid={badge.testId}>
                <CardContent className="p-4 flex flex-col items-center gap-2">
                  <badge.icon className="h-6 w-6 md:h-8 md:w-8 text-primary" />
                  <p className="text-xs md:text-sm font-medium text-center">{badge.text}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <Link href="/products">
            <Button size="lg" className="text-lg px-8" data-testid="button-shop-now">
              Shop Now
            </Button>
          </Link>
        </div>
      </section>

      <section className="py-16 px-4 bg-card">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-heading font-bold text-center mb-12">
            Why Choose Infinity Gallery?
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="hover-elevate transition-all">
              <CardContent className="p-6">
                <Shield className="h-12 w-12 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-2">Quality Guaranteed</h3>
                <p className="text-muted-foreground">
                  No corrupted, damaged, or duplicate items. Only clean and verified products.
                </p>
              </CardContent>
            </Card>

            <Card className="hover-elevate transition-all">
              <CardContent className="p-6">
                <Truck className="h-12 w-12 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-2">Fast Delivery</h3>
                <p className="text-muted-foreground">
                  2-5 business days delivery across Bangladesh. Track your order every step.
                </p>
              </CardContent>
            </Card>

            <Card className="hover-elevate transition-all">
              <CardContent className="p-6">
                <MessageCircle className="h-12 w-12 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-2">24/7 Support</h3>
                <p className="text-muted-foreground">
                  Customer support available via phone and WhatsApp anytime you need help.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-heading font-bold mb-6">
            Ready to Shop?
          </h2>
          <p className="text-lg text-muted-foreground mb-8">
            Browse our collection of premium fashion and accessories
          </p>
          <Link href="/products">
            <Button size="lg" variant="outline" data-testid="button-browse-products">
              Browse Products
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
