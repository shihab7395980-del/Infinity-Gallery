import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ProductCard } from "@/components/product/ProductCard";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import type { Product, CartItem } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

interface ProductsPageProps {
  onAddToCart: (item: CartItem) => void;
}

export function ProductsPage({ onAddToCart }: ProductsPageProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const { toast } = useToast();

  const queryUrl = selectedCategory === "all"
    ? "/api/products"
    : `/api/products?category=${selectedCategory}`;

  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: [queryUrl],
  });

  const categories = [
    { value: "all", label: "All Products" },
    { value: "fashion", label: "Fashion" },
    { value: "accessories", label: "Accessories" },
    { value: "lifestyle", label: "Lifestyle" },
  ];

  const handleAddToCart = (product: Product) => {
    const cartItem: CartItem = {
      productId: product.id,
      name: product.name,
      price: product.price,
      quantity: 1,
      image: product.image,
    };
    onAddToCart(cartItem);
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart.`,
    });
  };

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-6xl mx-auto px-4 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl lg:text-4xl font-heading font-bold mb-6" data-testid="text-products-title">
            Shop Our Collection
          </h1>

          <div className="flex flex-wrap gap-2 mb-8">
            {categories.map((category) => (
              <Button
                key={category.value}
                variant={selectedCategory === category.value ? "default" : "outline"}
                onClick={() => setSelectedCategory(category.value)}
                data-testid={`button-category-${category.value}`}
              >
                {category.label}
              </Button>
            ))}
          </div>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="space-y-3">
                <Skeleton className="aspect-[3/4] w-full" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
              </div>
            ))}
          </div>
        ) : products && products.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {products.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onAddToCart={handleAddToCart}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <p className="text-lg text-muted-foreground">No products found in this category.</p>
          </div>
        )}
      </div>
    </div>
  );
}
