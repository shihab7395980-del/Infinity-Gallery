import { Card, CardContent } from "@/components/ui/card";
import { Shield, Heart, Truck } from "lucide-react";

export function AboutPage() {
  return (
    <div className="min-h-screen py-12">
      <div className="max-w-4xl mx-auto px-4 lg:px-8">
        <h1 className="text-3xl lg:text-4xl font-heading font-bold mb-6" data-testid="text-about-title">
          About Infinity Gallery
        </h1>

        <div className="prose prose-lg max-w-none space-y-6 text-muted-foreground mb-12">
          <p className="text-lg leading-relaxed">
            Infinity Gallery is a Bangladesh-based online shopping store providing premium fashion, 
            accessories, and lifestyle products. We focus on quality, customer satisfaction, and safe delivery.
          </p>

          <p className="text-lg leading-relaxed">
            Our mission is to offer affordable products with a smooth online shopping experience. 
            No corrupted, damaged, or duplicate items — only clean and verified products.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <Card className="hover-elevate transition-all">
            <CardContent className="p-6 text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
                <Shield className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-semibold text-lg mb-2">Quality Assured</h3>
              <p className="text-sm text-muted-foreground">
                100% genuine products with no compromises on quality
              </p>
            </CardContent>
          </Card>

          <Card className="hover-elevate transition-all">
            <CardContent className="p-6 text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
                <Heart className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-semibold text-lg mb-2">Customer First</h3>
              <p className="text-sm text-muted-foreground">
                Your satisfaction is our top priority, always
              </p>
            </CardContent>
          </Card>

          <Card className="hover-elevate transition-all">
            <CardContent className="p-6 text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
                <Truck className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-semibold text-lg mb-2">Fast Delivery</h3>
              <p className="text-sm text-muted-foreground">
                Quick and reliable shipping across Bangladesh
              </p>
            </CardContent>
          </Card>
        </div>

        <Card className="bg-muted">
          <CardContent className="p-8">
            <h2 className="text-2xl font-heading font-bold mb-4">Our Commitment</h2>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-start">
                <span className="text-primary mr-2">✓</span>
                <span>We ensure all products are authentic and of the highest quality</span>
              </li>
              <li className="flex items-start">
                <span className="text-primary mr-2">✓</span>
                <span>Transparent pricing with no hidden charges</span>
              </li>
              <li className="flex items-start">
                <span className="text-primary mr-2">✓</span>
                <span>Secure payment options including Cash on Delivery and bKash</span>
              </li>
              <li className="flex items-start">
                <span className="text-primary mr-2">✓</span>
                <span>24/7 customer support via phone and WhatsApp</span>
              </li>
              <li className="flex items-start">
                <span className="text-primary mr-2">✓</span>
                <span>Hassle-free returns within 24 hours for damaged or wrong products</span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
