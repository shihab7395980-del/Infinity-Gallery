import { Card, CardContent } from "@/components/ui/card";
import { Banknote, CreditCard, MessageCircle } from "lucide-react";

export function PaymentMethodsPage() {
  return (
    <div className="min-h-screen py-12">
      <div className="max-w-4xl mx-auto px-4 lg:px-8">
        <h1 className="text-3xl lg:text-4xl font-heading font-bold mb-6" data-testid="text-payment-title">
          Payment Methods
        </h1>

        <p className="text-lg text-muted-foreground mb-12">
          We offer flexible and secure payment options for your convenience.
        </p>

        <div className="space-y-6">
          <Card className="hover-elevate transition-all">
            <CardContent className="p-6 md:p-8">
              <div className="flex items-start gap-4 mb-4">
                <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 shrink-0">
                  <Banknote className="h-6 w-6 text-primary" />
                </div>
                <div className="flex-1">
                  <h2 className="text-2xl font-heading font-bold mb-2">Cash on Delivery (COD)</h2>
                  <p className="text-muted-foreground">Pay when your product arrives at your doorstep</p>
                </div>
              </div>

              <div className="space-y-3 text-muted-foreground pl-16">
                <p className="font-semibold text-foreground">How it works:</p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <span className="text-primary mr-2">1.</span>
                    <span>Place your order on the website</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-primary mr-2">2.</span>
                    <span>Confirm order via WhatsApp: 01612963954</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-primary mr-2">3.</span>
                    <span>Receive your product within 2-5 business days</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-primary mr-2">4.</span>
                    <span>Pay in cash to the delivery person</span>
                  </li>
                </ul>

                <div className="bg-muted p-4 rounded-md mt-4">
                  <p className="text-sm font-medium text-foreground">
                    ✓ Most convenient option • No advance payment required
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover-elevate transition-all">
            <CardContent className="p-6 md:p-8">
              <div className="flex items-start gap-4 mb-4">
                <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 shrink-0">
                  <CreditCard className="h-6 w-6 text-primary" />
                </div>
                <div className="flex-1">
                  <h2 className="text-2xl font-heading font-bold mb-2">bKash Payment</h2>
                  <p className="text-muted-foreground">Pay securely using bKash mobile banking</p>
                </div>
              </div>

              <div className="space-y-3 text-muted-foreground pl-16">
                <p className="font-semibold text-foreground">How it works:</p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <span className="text-primary mr-2">1.</span>
                    <span>Place your order and select "bKash Payment"</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-primary mr-2">2.</span>
                    <span>Make payment to our bKash number (will be provided via WhatsApp)</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-primary mr-2">3.</span>
                    <span>Send payment screenshot to WhatsApp: 01612963954</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-primary mr-2">4.</span>
                    <span>Your order will be processed immediately after verification</span>
                  </li>
                </ul>

                <div className="bg-muted p-4 rounded-md mt-4">
                  <p className="text-sm font-medium text-foreground mb-2">
                    ✓ Advance payment or full payment accepted
                  </p>
                  <p className="text-sm">
                    Note: After payment, send screenshot to WhatsApp for quick verification
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-primary text-primary-foreground">
            <CardContent className="p-6 md:p-8">
              <div className="flex items-start gap-4">
                <MessageCircle className="h-8 w-8 shrink-0" />
                <div>
                  <h3 className="text-xl font-heading font-bold mb-2">Need Help?</h3>
                  <p className="mb-4 opacity-90">
                    For any payment-related queries, contact us on WhatsApp
                  </p>
                  <a
                    href="https://wa.me/8801612963954"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-block bg-white text-primary px-6 py-2 rounded-md font-semibold hover-elevate transition-all"
                    data-testid="button-whatsapp-payment-help"
                  >
                    Chat on WhatsApp
                  </a>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
