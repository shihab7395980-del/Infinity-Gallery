import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

export function PoliciesPage() {
  return (
    <div className="min-h-screen py-12">
      <div className="max-w-4xl mx-auto px-4 lg:px-8">
        <h1 className="text-3xl lg:text-4xl font-heading font-bold mb-8" data-testid="text-policies-title">
          Our Policies
        </h1>

        <div className="space-y-8">
          <Card>
            <CardContent className="p-6 md:p-8">
              <h2 className="text-2xl font-heading font-bold mb-4">Order Policy</h2>
              <div className="space-y-4 text-muted-foreground leading-relaxed">
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="text-primary mr-2 font-bold">•</span>
                    <span>All orders must be confirmed via phone call or WhatsApp</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-primary mr-2 font-bold">•</span>
                    <span><strong>Cash on Delivery:</strong> Pay only after receiving your product</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-primary mr-2 font-bold">•</span>
                    <span><strong>bKash Payment:</strong> Advance or full payment accepted</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-primary mr-2 font-bold">•</span>
                    <span><strong>Delivery Time:</strong> 2-5 business days inside Bangladesh</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-primary mr-2 font-bold">•</span>
                    <span>No fake or corrupted products allowed</span>
                  </li>
                </ul>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 md:p-8">
              <h2 className="text-2xl font-heading font-bold mb-4">Return & Replacement Policy</h2>
              <div className="space-y-4 text-muted-foreground leading-relaxed">
                <p>We accept returns only if:</p>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-start">
                    <span className="text-primary mr-2 font-bold">•</span>
                    <span>Product is damaged</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-primary mr-2 font-bold">•</span>
                    <span>Wrong product delivered</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-primary mr-2 font-bold">•</span>
                    <span>Size or color mismatch (seller fault)</span>
                  </li>
                </ul>

                <div className="border-l-4 border-primary pl-4 bg-muted p-4 rounded-md">
                  <p className="font-semibold mb-2">Important:</p>
                  <ul className="space-y-2 text-sm">
                    <li>• Return request must be made within <strong>24 hours</strong> of receiving the product</li>
                    <li>• Customer must provide photo/video proof</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 md:p-8">
              <h2 className="text-2xl font-heading font-bold mb-4">Delivery Policy</h2>
              <div className="space-y-4 text-muted-foreground leading-relaxed">
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="text-primary mr-2 font-bold">•</span>
                    <span>We deliver all across Bangladesh</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-primary mr-2 font-bold">•</span>
                    <span>Standard delivery: 2-5 business days</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-primary mr-2 font-bold">•</span>
                    <span>Delivery charges may vary based on location</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-primary mr-2 font-bold">•</span>
                    <span>Orders are processed after confirmation via phone/WhatsApp</span>
                  </li>
                </ul>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 md:p-8">
              <h2 className="text-2xl font-heading font-bold mb-4">Privacy & Security</h2>
              <div className="space-y-4 text-muted-foreground leading-relaxed">
                <p>
                  Your personal information is safe with us. We use your contact details only for 
                  order confirmation and delivery purposes. We never share your information with 
                  third parties.
                </p>
                <p>
                  All payment information is handled securely. For bKash payments, we confirm 
                  transactions through WhatsApp verification.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
