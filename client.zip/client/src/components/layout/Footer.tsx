import { Link } from "wouter";
import { Phone, MessageCircle } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-card border-t mt-auto">
      <div className="max-w-7xl mx-auto px-4 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-heading font-bold mb-4">Infinity Gallery</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Your trusted online shopping store for premium fashion and accessories. 
              We focus on quality, customer satisfaction, and safe delivery across Bangladesh.
            </p>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <nav className="flex flex-col gap-2">
              <Link href="/about">
                <a className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="footer-link-about">
                  About Us
                </a>
              </Link>
              <Link href="/contact">
                <a className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="footer-link-contact">
                  Contact
                </a>
              </Link>
              <Link href="/policies">
                <a className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="footer-link-policies">
                  Policies
                </a>
              </Link>
              <Link href="/payment-methods">
                <a className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="footer-link-payment">
                  Payment Methods
                </a>
              </Link>
            </nav>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Contact Us</h4>
            <div className="flex flex-col gap-3 text-sm">
              <a
                href="tel:01612963954"
                className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
                data-testid="footer-phone"
              >
                <Phone className="h-4 w-4" />
                <span>01612963954</span>
              </a>
              <a
                href="https://wa.me/8801612963954"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
                data-testid="footer-whatsapp"
              >
                <MessageCircle className="h-4 w-4" />
                <span>WhatsApp: 01612963954</span>
              </a>
              <p className="text-muted-foreground">Bangladesh</p>
            </div>
          </div>
        </div>

        <div className="border-t mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
            <p>© Infinity Gallery — All Rights Reserved.</p>
            <p className="text-center md:text-right">
              Fast Delivery • Cash on Delivery • bKash Payment • Customer Support 24/7
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
